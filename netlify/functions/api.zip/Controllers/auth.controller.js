var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var auth_controller_exports = {};
__export(auth_controller_exports, {
  google: () => google,
  loginUser: () => loginUser,
  registerUser: () => registerUser
});
module.exports = __toCommonJS(auth_controller_exports);
var import_userModel = __toESM(require("../Models/userModel.js"), 1);
var import_Error = require("../Utils/Error.js");
var import_bcryptjs = __toESM(require("bcryptjs"), 1);
var import_jsonwebtoken = __toESM(require("jsonwebtoken"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
import_dotenv.default.config();
const registerUser = async (req, res, next) => {
  const { username, email, password } = req.body;
  if (!username || !email || !password || username === "" || email === "" || password === "") {
    return next((0, import_Error.errorHandler)(400, "All the Fields Are Required"));
  }
  const hashedPassword = import_bcryptjs.default.hashSync(password, 10);
  const newUser = new import_userModel.default({ username, email, password: hashedPassword });
  try {
    await newUser.save();
    res.status(200).json({ message: "User Registered Successfully", result: newUser });
  } catch (error) {
    next(error);
  }
};
const loginUser = async (req, res, next) => {
  const { email, password } = req.body;
  if (!email || !password || email === "" || password === "") {
    return next((0, import_Error.errorHandler)(400, "All the Fields Are Required"));
  }
  try {
    const userDetail = await import_userModel.default.findOne({ email });
    const userPassword = import_bcryptjs.default.compareSync(password, userDetail.password);
    if (!userDetail || !userPassword) {
      return next((0, import_Error.errorHandler)(400, "Invalid Credentials"));
    }
    const token = import_jsonwebtoken.default.sign(
      { id: userDetail._id, isAdmin: userDetail.isAdmin },
      process.env.JWT_SECRET_KEY
    );
    const { password: passkey, ...rest } = userDetail._doc;
    res.status(200).json({ message: "User LoggedIn Successfully", rest, token });
  } catch (error) {
    next(error);
  }
};
const google = async (req, res, next) => {
  const { email, name, profilePic } = req.body;
  try {
    const user = await import_userModel.default.findOne({ email });
    if (user) {
      const token = import_jsonwebtoken.default.sign(
        { id: user._id, isAdmin: user.isAdmin },
        process.env.JWT_SECRET_KEY
      );
      console.log(user);
      const { password: passkey, ...rest } = user._doc;
      res.status(200).json({ message: "User LoggedIn Successfully", rest, token });
    } else {
      const generatePassword = Math.random().toString(36).slice(-8) + Math.random().toString(36).slice(-8);
      const hashedPassword = import_bcryptjs.default.hashSync(generatePassword, 10);
      const newUser = new import_userModel.default({
        username: name?.toLowerCase().split(" ").join("") + Math.random().toString(9).slice(-4),
        email,
        password: hashedPassword,
        profilePicture: profilePic
      });
      console.log(newUser);
      await newUser.save();
      const token = import_jsonwebtoken.default.sign(
        { id: newUser._id, isAdmin: newUser.isAdmin },
        process.env.JWT_SECRET_KEY
      );
      const { password: passkey, ...rest } = newUser._doc;
      res.status(200).json({ message: "User LoggedIn Successfully", rest, token });
    }
  } catch (error) {
    next(error);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  google,
  loginUser,
  registerUser
});
